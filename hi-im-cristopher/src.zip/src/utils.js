// para importar de forma dinamica las imagenes en la carpeta assets desde internet
export const getImageUrl = (path) => `/assets/${path}`;

  